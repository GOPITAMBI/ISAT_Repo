from dotenv import dotenv_values
from pydruid.db import connect
from pydruid.db.exceptions import ProgrammingError
from requests import ConnectionError
import pandas as pd
from django.utils.timezone import now

env = dict(dotenv_values())
druid = {
    "host": env["DRUID_HOST"],
    "port": env["DRUID_PORT"],
    "path": env["DRUID_PATH"],
    "scheme": env["DRUID_SCHEME"],
}
current_year = now().year


# Location Lookups | Hierarchy -- State > District > Block

def get_states():
    try:
        query = f"""
            SELECT DISTINCT "state_id", "state_name" FROM "druid"."grid-rainfall-data" WHERE 
            "__time" BETWEEN DATE_TRUNC('YEAR', TIMESTAMPADD(YEAR, -2, CURRENT_TIMESTAMP)) AND DATE_TRUNC('YEAR', TIMESTAMPADD(YEAR, -1, CURRENT_TIMESTAMP))
            ORDER BY "state_name"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            result = [{"state_id": i[1], "state": i[2]} for i in query_result]
            return {"status": 1, "data": result}
    except ProgrammingError:
        return {"status": 0, "message": "Error in getting states, please check query"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}


def get_districts(state_id):
    try:
        query = f"""
            SELECT DISTINCT "state_id", "district_id", "district_name" FROM "druid"."grid-rainfall-data" WHERE
            "__time" BETWEEN DATE_TRUNC('YEAR', TIMESTAMPADD(YEAR, -2, CURRENT_TIMESTAMP)) AND DATE_TRUNC('YEAR', TIMESTAMPADD(YEAR, -1, CURRENT_TIMESTAMP))
            AND "state_id"={state_id} ORDER BY "district_name"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            result = [{"state_id": i[1], "district_id": i[2], "district": i[3]} for i in query_result]
            return {"status": 1, "data": result}
    except ProgrammingError:
        return {"status": 0, "message": f"Error in getting districts, please check query"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}


def get_blocks(state_id, district_id):
    try:
        query = f"""
            SELECT DISTINCT "state_id", "district_id", "block_id", "block_name" FROM "druid"."grid-rainfall-data" WHERE 
            "__time" BETWEEN DATE_TRUNC('YEAR', TIMESTAMPADD(YEAR, -2, CURRENT_TIMESTAMP)) AND DATE_TRUNC('YEAR', TIMESTAMPADD(YEAR, -1, CURRENT_TIMESTAMP))
            AND "state_id"={state_id} AND "district_id"={district_id} ORDER BY "block_name"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            result = [{"state_id": i[1], "district_id": i[2], "block_id": i[3], "block": i[4]} for i in query_result]
            return {"status": 1, "data": result}
    except ProgrammingError:
        return {"status": 0, "message": f"Error in getting blocks, please check query"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
