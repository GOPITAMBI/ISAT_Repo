from django.urls import path
from . import views

urlpatterns = [
    path('states', views.states, name='states'),
    path('districts', views.districts, name='districts'),
    path('blocks', views.blocks, name='blocks'),
    path('months', views.months, name='months'),
    path('weeks', views.weeks, name='weeks'),
    path('crops', views.crops, name='crops'),
]
