from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
# from .fetch_druid import get_states, get_districts, get_blocks
from .lookup_objects import month_list, week_list, crop_list, \
    states_list, districts_list, blocks_list


@csrf_exempt
@require_http_methods(['GET'])
def states(request):
    result = sorted(states_list, key=lambda x: x.get("state"))
    return JsonResponse({"status": 1, "data": result}, status=200)


@csrf_exempt
@require_http_methods(['GET'])
def districts(request):
    state_id = request.GET.get('stateId')
    # if state_id:
    #     result = get_districts(state_id)
    #     return JsonResponse(result, status=200) if result["status"] else JsonResponse(result, status=500)
    # else:
    #     return JsonResponse({"status": 0, "message": "State ID is required for districts"}, status=400)
    result = list(filter(lambda x: x.get("state_id") == int(state_id), districts_list))
    result = sorted(result, key=lambda x: x.get("district"))
    return JsonResponse({"status": 1, "data": result}, status=200) 


@csrf_exempt
@require_http_methods(['GET'])
def blocks(request):
    state_id = request.GET.get('stateId')
    district_id = request.GET.get('districtId')
    # if state_id and district_id:
    #     result = get_blocks(state_id, district_id)
    #     return JsonResponse(result, status=200) if result["status"] else JsonResponse(result, status=500)
    # else:
    #     return JsonResponse({"status": 0, "message": "State ID, District ID are required for blocks"}, status=400)
    result = list(filter(lambda x: x.get("state_id") == int(state_id) and x.get("district_id") == int(district_id), blocks_list))
    result = sorted(result, key=lambda x: x.get("block"))
    return JsonResponse({"status": 1, "data": result}, status=200)


# If going to use a database, create equivalent models for those in lookup_objects

@csrf_exempt
@require_http_methods(['GET'])
def months(request):
    try:
        result = list(map(lambda x: {"month_id": x["id"], "month": x["month_text"]}, month_list))
        return JsonResponse({"status": 1, "data": result}, status=200)
    except (TypeError, ValueError, IndexError, AttributeError, ModuleNotFoundError):
        return JsonResponse({"status": 0, "message": "Couldn't get months' list"}, status=500)


@csrf_exempt
@require_http_methods(['GET'])
def weeks(request):
    try:
        result = list(map(lambda x: {"week_id": x["id"], "week": x["week_text"]}, week_list))
        return JsonResponse({"status": 1, "data": result}, status=200)
    except (TypeError, ValueError, IndexError, AttributeError, ModuleNotFoundError):
        return JsonResponse({"status": 0, "message": "Couldn't get weeks' list"}, status=500)


@csrf_exempt
@require_http_methods(['GET'])
def crops(request):
    try:
        result = list(map(lambda x: {"crop_id": x["id"], "in_districts": x["in_districts"],  "crop": x["crop"], "is_variety": x["is_variety"], "variety_parent": x["variety_parent"]}, crop_list))
        return JsonResponse({"status": 1, "data": result}, status=200)
    except (TypeError, ValueError, IndexError, AttributeError, ModuleNotFoundError):
        return JsonResponse({"status": 0, "message": "Couldn't get crops' list"}, status=500)
