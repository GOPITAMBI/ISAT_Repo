from django.urls import path
from . import views

urlpatterns = [
    path('todays_weather', views.todays_weather, name='todays_weather'),
    path('medium_range_forecast', views.medium_range_forecast, name='medium_range_forecast'),
    path('extended_range_forecast', views.extended_range_forecast, name='extended_range_forecast'),
    path('seasonal_forecast', views.seasonal_forecast, name='seasonal_forecast'), 
    # Advisory ?
]
