from dotenv import dotenv_values
from pydruid.db import connect
from pydruid.db.exceptions import ProgrammingError
from requests import ConnectionError
import pandas as pd
from django.utils.timezone import now
from datetime import timedelta, datetime, date
from lookups.lookup_objects import met_week_long, week_list, month_list


env = dict(dotenv_values())
druid = {
    "host": env["DRUID_HOST"],
    "port": env["DRUID_PORT"],
    "path": env["DRUID_PATH"],
    "scheme": env["DRUID_SCHEME"],
}
current_year = now().year
current_year_filter = f""" AND "year"={current_year}"""
past_30year_filter = f""" AND "year">={current_year-30} AND "year"<={current_year-1}"""
current_day = now().day
current_month = now().month
current_week = next(i for i in met_week_long if i["day"] == current_day and i["month"] == current_month)["met_week"]

previous_day = (now() - timedelta(days=1)).day
previous_day_month = (now() - timedelta(days=1)).month


def get_todays_weather(**kwargs):
    curdate = now().date().strftime("%Y-%m-%d")
    curdate_p1 = (now() + timedelta(days=1)).date().strftime("%Y-%m-%d")
    block_id = kwargs.get('block_id')
    try:
        # query = f"""
        #     SELECT "__time", "block_lat", "block_lon", "block_name", "district_name", "state_name",
        #     "rainfall", "temp_max", "temp_min", "humidity_I", "humidity_II", "wind_speed"
        #     FROM  "druid"."medium-range-forecast" WHERE 1=1 AND "block_id"={block_id}
        #     AND "__time" >= '{(now() - timedelta(days=8)).strftime("%Y-%m-%d")}'
        #     AND "__time" <= '{(now() + timedelta(days=1)).strftime("%Y-%m-%d")}'
        # """
        # with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
        #     query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
        #     day_list = [{
        #         "date": datetime.strptime(i[1][:10], "%Y-%m-%d").strftime("%Y-%m-%d") , "lat": i[2], "lon": i[3], "block": i[4], "district": i[5], "state": i[6],
        #         "rainfall": round(i[7], 2), "max_temp": round(i[8], 2), "min_temp": round(i[9], 2), 
        #         "avg_rh": round((i[10]+i[11])/2, 2), "wind_speed": round(i[12], 2)
        #     }  for i in query_result]
        #     todays_weather = next((i for i in day_list if i["date"] == now().strftime("%Y-%m-%d")), None)
        #     latest_weather_list = list(filter(lambda x: datetime.strptime(x["date"], "%Y-%m-%d"), day_list))
        #     latest_weather = latest_weather_list[len(latest_weather_list) - 1] if latest_weather_list else None
        #     return {"status": 1, "data": todays_weather or latest_weather}

        query = f"""
            SELECT "forecast_date", "block_lat", "block_lon", "block_name", "district_name", "state_name",
            "rainfall", "temp_max", "temp_min", "humidity_I", "humidity_II", "wind_speed", "__time"
            FROM  "druid"."medium-range-forecast" 
            WHERE TRUE AND "block_id"='{block_id}' 
            AND "forecast_date" IN ('{curdate}', '{curdate_p1}') ORDER BY "__time" DESC LIMIT 1
        """
        print(query)
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            if query_result:
                i = query_result[0]
                data = {
                    "date": datetime.strptime(i[1][:10], "%Y-%m-%d").strftime("%Y-%m-%d"),
                    "lat": i[2], 
                    "lon": i[3], 
                    "block": i[4],
                    "district": i[5], 
                    "state": i[6],
                    "rainfall": round(i[7], 2), 
                    "max_temp": round(i[8], 2), 
                    "min_temp": round(i[9], 2), 
                    "avg_rh": round((i[10]+i[11])/2, 2), 
                    "wind_speed": round(i[12], 2),
                    "ref_date": i[13],
                }
            else: 
                 data = None
            return {"status": 1, "data": data}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_medium_range_forecast(**kwargs):
    curdate = now().date().strftime("%Y-%m-%d")
    block_id = kwargs.get('block_id')
    # block_filter = f""" AND "block_id"={block_id} """ if block_id else ""
    try:
        query = f"""
            SELECT "forecast_date", 
            "block_name", 
            "rainfall",
            "temp_min",
            "temp_max",
            "cloud_cover_octa",
            "humidity_I",
            "humidity_II",
            "wind_direction",
            "wind_speed"
            FROM "druid"."medium-range-forecast"
            WHERE TRUE AND "block_id"='{block_id}'
            AND "__time"=(SELECT MAX("__time") FROM "druid"."medium-range-forecast" WHERE TRUE AND "block_id"='{block_id}')
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            data = [{
                "date": i[1][:10], "block_name": i[2], "rainfall": i[3],
                "min_temp": i[4], "max_temp": i[5], "cloud_cover": i[6], "min_rh": i[7], "max_rh": i[8],
                "wind_dir": i[9], "wind_speed": i[10]
            } for i in query_result]
            return {"status": 1, "data": data}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_extended_range_forecast(**kwargs):
    block_id = kwargs.get('block_id')
    today = date.today()
    end_day = today + timedelta(weeks=4)
    date_diff = (end_day - today).days
    date_list = [today]
    for i in range(1, date_diff):
        date_list.append(today + timedelta(days=i))
    wednesday_list = list(filter(lambda x: x.weekday() == 2, date_list))
    four_weeks = []
    wk = 0
    for wednesday in wednesday_list:
        start_day = wednesday
        end_day = start_day + timedelta(days=6)
        wk += 1
        four_weeks.append({"week": wk, "start": start_day, "end": end_day})
    
    cy_forecast = []
    for i in four_weeks:
        try:
            query1 = f"""
                SELECT ROUND(SUM("forecast_rainfall"), 2) FROM "druid"."extended-range-forecast"
                WHERE "__time">='{i["start"].strftime(("%Y-%m-%d"))}T00:00:00.000Z' 
                AND "__time"<='{i["end"].strftime("%Y-%m-%d")}T00:00:00.000Z' AND "block_id"={block_id} 
                AND "year"={current_year}
            """
            with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
                query1_result = list(pd.DataFrame(connection.execute(query1), dtype=object).to_records())
                if(len(query1_result)):
                    cy_forecast.append({"week": i["week"], "rf": query1_result[0][1]})
                else:
                    cy_forecast.append({"week": i["week"], "rf": None})
        except ProgrammingError:
            return {"status": 0, "message": "Error in query, please rectify - current year forecast"}
        except ConnectionError:
            return {"status": 0, "message": "Couldn't connect to imd-druid database - current year forecast"}
        except IndexError:
            return {"status": 0, "message": "No results for selected block - current year forecast"}
    
    py_observed = []
    py_hindcast = []
    for year in range(2003, current_year):
        for i in four_weeks:
            try:
                query2 = f"""
                    SELECT ROUND(SUM("grid_rainfall"), 2) FROM "druid"."grid-rainfall-data"
                    WHERE "year"={year} AND "block_id"={block_id}
                    AND "__time">='{year}-{i["start"].strftime("%m-%d")}T00:00:00.000Z'
                    AND "__time"<='{year}-{i["end"].strftime("%m-%d")}T00:00:00.000Z'
                """
                query3 = f"""
                    SELECT ROUND(SUM("forecast_rainfall"), 2) FROM "druid"."extended-range-forecast"
                    WHERE "year"={year} AND "block_id"={block_id}
                    AND "__time">='{year}-{i["start"].strftime("%m-%d")}T00:00:00.000Z'
                    AND "__time"<='{year}-{i["end"].strftime("%m-%d")}T00:00:00.000Z'
                """
                with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
                    query2_result = list(pd.DataFrame(connection.execute(query2), dtype=object).to_records())
                    if(len(query2_result)):
                        py_observed.append({"week": i["week"], "year": year, "rf": query2_result[0][1]})
                    else:
                        py_observed.append({"week": i["week"], "year": year, "rf": None})
                    
                    query3_result = list(pd.DataFrame(connection.execute(query3), dtype=object).to_records())
                    if(len(query3_result)):
                        py_hindcast.append({"week": i["week"], "year": year, "rf": query3_result[0][1]})
                    else:
                        py_hindcast.append({"week": i["week"], "year": year, "rf": None})
            except ProgrammingError:
                return {"status": 0, "message": f"Error in query, please rectify {year}"}
            except ConnectionError:
                return {"status": 0, "message": f"Couldn't connect to imd-druid database {year}"}
            except IndexError:
                return {"status": 0, "message": f"No results for selected block {year}"}


    py_observed_average = []
    for i in four_weeks:
        past_vals = list(filter(lambda x: x["week"] == i["week"], py_observed))
        past_vals_rf = list(map(lambda x: x["rf"] if isinstance(x["rf"], (int, float)) else 0, past_vals))
        py_observed_average.append({"week": i["week"], "rf": round((sum(past_vals_rf)/len(past_vals_rf)), 2)}) 

    for i in cy_forecast:
        obs = next(j for j in py_observed_average if j["week"] == i["week"])
        i["hist_avg_obs_rf"] = obs["rf"]
        i["outlook"] = ("AN" if i["rf"] >= obs["rf"] else "BN") if isinstance(i["rf"], (int, float)) else None
    
    for i in py_observed:
        obs = next(j for j in py_observed_average if j["week"] == i["week"])
        i["hist_avg_obs_rf"] = obs["rf"]
        i["outlook"] = ("AN" if i["rf"] >= obs["rf"] else "BN") if isinstance(i["rf"], (int, float)) else None

    for i in py_hindcast:
        obs = next(j for j in py_observed_average if j["week"] == i["week"])
        i["hist_avg_obs_rf"] = obs["rf"]
        i["outlook"] = ("AN" if i["rf"] >= obs["rf"] else "BN") if isinstance(i["rf"], (int, float)) else None
    
    observed_outlook = []
    for i in four_weeks:
        count_an = len(list(filter(lambda x: x["outlook"] == "AN" and x["week"] == i["week"], py_observed)))
        count_bn = len(list(filter(lambda x: x["outlook"] == "BN" and x["week"] == i["week"], py_observed)))
        observed_outlook.append({"week": i["week"], "AN": count_an, "BN": count_bn})

    hindcast_outlook = []
    for i in four_weeks:
        count_an = len(list(filter(lambda x: x["outlook"] == "AN" and x["week"] == i["week"], py_hindcast)))
        count_bn = len(list(filter(lambda x: x["outlook"] == "BN" and x["week"] == i["week"], py_hindcast)))
        hindcast_outlook.append({"week": i["week"], "AN": count_an, "BN": count_bn})
    
    hits_and_misses = []
    for i in four_weeks:
        hm = {"week": i["week"]}
        hits = 0
        misses = 0
        for year in range(2003, current_year):
            if next(j for j in py_observed if j["week"] == i["week"] and j["year"] == year)["outlook"]\
                == next(j for j in py_hindcast if j["week"] == i["week"] and j["year"] == year)["outlook"]:
                hits += 1
            else:
                misses += 1
        hm.update({"hits": hits, "misses": misses})
        hits_and_misses.append(hm)
    
    for i in hits_and_misses:
        i["hits_pc"] = round((i["hits"]*100) / (i["hits"] + i["misses"]), 2)
        i["misses_pc"] = round((i["misses"]*100) / (i["hits"] + i["misses"]), 2)
    
    outlooks_summary = []
    for i in four_weeks:
        outlooks_summary_item = {}
        outlooks_summary_item["week"] = i["week"]
        outlooks_summary_item["obs_an"] = next(j for j in observed_outlook if j["week"] == i["week"])["AN"]
        outlooks_summary_item["obs_bn"] = next(j for j in observed_outlook if j["week"] == i["week"])["BN"]
        outlooks_summary_item["fc_an"] = next(j for j in hindcast_outlook if j["week"] == i["week"])["AN"]
        outlooks_summary_item["fc_bn"] = next(j for j in hindcast_outlook if j["week"] == i["week"])["BN"]
        outlooks_summary_item["hits"] = next(j for j in hits_and_misses if j["week"] == i["week"])["hits"]
        outlooks_summary_item["misses"] = next(j for j in hits_and_misses if j["week"] == i["week"])["misses"]
        outlooks_summary_item["hits_pc"] = next(j for j in hits_and_misses if j["week"] == i["week"])["hits_pc"]
        outlooks_summary_item["misses_pc"] = next(j for j in hits_and_misses if j["week"] == i["week"])["misses_pc"]
        outlooks_summary.append(outlooks_summary_item)

    return {"status": 1, "data": {
        "dates": four_weeks,
        "current_year_forecast": cy_forecast,
        "outlooks_summary": outlooks_summary
    }}


def get_seasonal_forecast(**kwargs):
    # CURRENTLY THIS USES ONLY RAINFALL
    block_id = kwargs.get('block_id')
    ic_month_id = kwargs.get('ic_month_id')
    
    observed = []
    try:
        query1 = f"""
            SELECT "year", ROUND(SUM("grid_rainfall"), 2) FROM "druid"."grid-rainfall-data"
            WHERE "month_num" BETWEEN 6 AND 9 AND "year">={current_year-30} AND "block_id"={block_id} GROUP BY "year"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query1_result = list(pd.DataFrame(connection.execute(query1), dtype=object).to_records())
            for i in query1_result:
                observed.append({"year": i[1], "obs_rf": i[2]})        
    except ProgrammingError:
        return {"status": 0, "message": f"Error in query, please rectify (get_seasonal_forecast_weather()) - observed"}
    except ConnectionError:
        return {"status": 0, "message": f"Couldn't connect to imd-druid database (get_seasonal_forecast_weather()) - observed"}
    except IndexError:
        return {"status": 0, "message": f"No results for selected block (get_seasonal_forecast_weather()) - observed"}
    observed_rf = list(map(lambda x: x["obs_rf"], observed))
    observed_rf_avg = round(sum(observed_rf)/len(observed_rf), 2)
    for i in observed:
        i["obs_avg_rf"] = observed_rf_avg
        i["obs_outlook"] = "AN" if i["obs_rf"] >= observed_rf_avg else "BN"

    ic_tables = {
        4: "seasonal-climate-forecast-april-ic",
        5: "seasonal-climate-forecast-may-ic",
        # 6: "seasonal-climate-forecast",
    }
    ic_source_table = ic_tables[ic_month_id]
    
    forecast = []
    try:
        query2 = f"""
            SELECT "year", ROUND(SUM("forecast_rainfall"), 2) FROM "druid"."{ic_source_table}"
            WHERE "month_num" BETWEEN 6 AND 9 AND "year">={current_year-30}  AND "block_id"={block_id} GROUP BY "year"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query2_result = list(pd.DataFrame(connection.execute(query2), dtype=object).to_records())
            for i in query2_result:
                forecast.append({"year": i[1], "fc_rf": i[2]})
    except ProgrammingError:
        return {"status": 0, "message": f"Error in query, please rectify (get_seasonal_forecast_weather()) - forecast"}
    except ConnectionError:
        return {"status": 0, "message": f"Couldn't connect to imd-druid database (get_seasonal_forecast_weather()) - forecast"}
    except IndexError:
        return {"status": 0, "message": f"No results for selected block (get_seasonal_forecast_weather()) - forecast"}
    forecast_rf = list(map(lambda x: x["fc_rf"], forecast))
    forecast_rf_avg = round(sum(forecast_rf)/len(forecast_rf), 2)
    for i in forecast:
        i["fc_avg_rf"] = forecast_rf_avg
        i["fc_outlook"] = "AN" if i["fc_rf"] >= forecast_rf_avg else "BN"

    from_year = min([min(list(map(lambda x: x["year"], observed))), min(list(map(lambda x: x["year"], forecast)))])
    # to_year = max([max(list(map(lambda x: x["year"], observed))), max(list(map(lambda x: x["year"], forecast)))])
    outlook_data = []
    for yr in range(from_year, current_year+1):
        obs_obj = list(filter(lambda x: x["year"] == yr, observed))
        obs_rf = obs_obj[0]["obs_rf"] if obs_obj else None
        obs_outlook = obs_obj[0]["obs_outlook"] if obs_obj else None
        fc_obj = list(filter(lambda x: x["year"] == yr, forecast))
        fc_rf = fc_obj[0]["fc_rf"] if fc_obj else None
        fc_outlook = fc_obj[0]["fc_outlook"] if fc_obj else None
        if obs_outlook and fc_outlook:
            match = "Hit" if obs_outlook == fc_outlook else "Miss"
        else:
            match = None
        outlook_data.append({ 
            "year": yr, "obs_rf": obs_rf, "fc_rf": fc_rf,
            "obs_outlook": obs_outlook, "fc_outlook": fc_outlook, "match": match
        })

    skill_data = {}
    for i in outlook_data:
        skill_data["observed_an_seasons"] = len(list(filter(lambda x: x["obs_outlook"] == "AN", outlook_data)))
        skill_data["observed_bn_seasons"] = len(list(filter(lambda x: x["obs_outlook"] == "BN", outlook_data)))
        skill_data["forecast_an_seasons"] = len(list(filter(lambda x: x["fc_outlook"] == "AN", outlook_data)))
        skill_data["forecast_bn_seasons"] = len(list(filter(lambda x: x["fc_outlook"] == "BN", outlook_data)))
        skill_data["total_observed_seasons"] = skill_data["observed_an_seasons"] + skill_data["observed_bn_seasons"]
        skill_data["total_forecast_seasons"] = skill_data["forecast_an_seasons"] + skill_data["forecast_bn_seasons"]
        skill_data["an_hits"] = len(list(filter(lambda x: x["fc_outlook"] == "AN" and x["match"] == "Hit", outlook_data)))
        skill_data["an_misses"] = len(list(filter(lambda x: x["fc_outlook"] == "AN" and x["match"] == "Miss", outlook_data)))
        skill_data["bn_hits"] = len(list(filter(lambda x: x["fc_outlook"] == "BN" and x["match"] == "Hit", outlook_data)))
        skill_data["bn_misses"] = len(list(filter(lambda x: x["fc_outlook"] == "BN" and x["match"] == "Miss", outlook_data)))
        skill_data["an_hits_pc"] = round((skill_data["an_hits"] * 100)/(skill_data["an_hits"] + skill_data["an_misses"]), 2)
        skill_data["an_misses_pc"] = round((skill_data["an_misses"] * 100)/(skill_data["an_hits"] + skill_data["an_misses"]), 2)
        skill_data["bn_hits_pc"] = round((skill_data["bn_hits"] * 100)/(skill_data["bn_hits"] + skill_data["bn_misses"]), 2)
        skill_data["bn_misses_pc"] = round((skill_data["bn_misses"] * 100)/(skill_data["bn_hits"] + skill_data["bn_misses"]), 2)
        skill_data["total_hits"] = skill_data["an_hits"] + skill_data["bn_hits"]
        skill_data["total_misses"] = skill_data["an_misses"] + skill_data["bn_misses"]

    return {"status": 1, "data": {
        "outlook_data": outlook_data,
        "skill_data": skill_data
    }}

