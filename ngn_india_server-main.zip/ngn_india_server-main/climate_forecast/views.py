from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from .fetch_druid import get_todays_weather, get_medium_range_forecast, get_extended_range_forecast, get_seasonal_forecast
from django.utils.timezone import now
from datetime import datetime, timedelta


@csrf_exempt
@require_http_methods(['POST'])
def todays_weather(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        if block_id:
            result = get_todays_weather(block_id=block_id)
            return JsonResponse(result, status=200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block Id is required"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def medium_range_forecast(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        if block_id:
            result = get_medium_range_forecast(block_id=block_id)
            return JsonResponse(result, status=200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block Id is required"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)



@csrf_exempt
@require_http_methods(['POST'])
def extended_range_forecast(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        if block_id:
            result = get_extended_range_forecast(block_id=block_id)
            return JsonResponse(result, status=200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block Id is required"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)



@csrf_exempt
@require_http_methods(['POST'])
def seasonal_forecast(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        ic_month_id = int(request_body["icMonthId"]) if "blockId" in request_body else 0
        if block_id:
            result = get_seasonal_forecast(block_id=block_id, ic_month_id=ic_month_id)
            return JsonResponse(result, status=200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block Id is required"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)