from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from .fetch_druid import current_year, \
    get_current_monthly_rainfall,  get_historic_monthly_rainfall, \
    get_current_weekly_rainfall, get_historic_weekly_rainfall, \
    get_current_daily_rainfall, get_historic_daily_rainfall, \
    get_current_monthly_temperature, get_historic_monthly_temperature, \
    get_current_weekly_temperature, get_historic_weekly_temperature, \
    get_current_daily_temperature, get_historic_daily_temperature
from django.utils.timezone import now
from datetime import datetime, timedelta


@csrf_exempt
@require_http_methods(['POST'])
def current_monthly_rainfall(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_month = int(request_body["fromMonth"]) if "fromMonth" in request_body else 1
        to_month = int(request_body["toMonth"]) if "toMonth" in request_body else 12
        if from_month > to_month:
            return JsonResponse({"status": 0, "message": "From month can't be later than To month"}, status=400)
        if block_id:
            result = get_current_monthly_rainfall(block_id=block_id, from_month=from_month, to_month=to_month)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_monthly_rainfall(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_month = int(request_body["fromMonth"]) if "fromMonth" in request_body else 1
        to_month = int(request_body["toMonth"]) if "toMonth" in request_body else 12
        if from_month > to_month:
            return JsonResponse({"status": 0, "message": "From month can't be later than To month"}, status=400)
        if block_id:
            result = get_historic_monthly_rainfall(block_id=block_id, from_month=from_month, to_month=to_month)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def current_weekly_rainfall(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "From week can't be later than To week"}, status=400)
        if block_id:
            result = get_current_weekly_rainfall(block_id=block_id, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_weekly_rainfall(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "From week can't be later than To week"}, status=400)
        if block_id:
            result = get_historic_weekly_rainfall(block_id=block_id, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def current_daily_rainfall(request):
    year_start_date = f"{current_year}-01-01"
    prev_day = (now() - timedelta(days=1)).strftime("%Y-%m-%d")
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_date = request_body["fromDate"] if "fromDate" in request_body else year_start_date
        to_date = request_body["toDate"] if "toDate" in request_body else prev_day
        if datetime.strptime(from_date, "%Y-%m-%d") > datetime.strptime(to_date, "%Y-%m-%d"):
            return JsonResponse({"status": 0, "message": "From date can't be later than To date, please check"}, status=400)
        if block_id:
            result = get_current_daily_rainfall(block_id=block_id, from_date=from_date, to_date=to_date)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_daily_rainfall(request):
    year_start_date = f"{current_year}-01-01"
    prev_day = (now() - timedelta(days=1)).strftime("%Y-%m-%d")
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_date = request_body["fromDate"] if "fromDate" in request_body else year_start_date
        to_date = request_body["toDate"] if "toDate" in request_body else prev_day
        if datetime.strptime(from_date, "%Y-%m-%d") > datetime.strptime(to_date, "%Y-%m-%d"):
            return JsonResponse({"status": 0, "message": "From date can't be later than To date, please check"}, status=400)
        if block_id:
            result = get_historic_daily_rainfall(block_id=block_id, from_date=from_date, to_date=to_date)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def current_monthly_temperature(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_month = int(request_body["fromMonth"]) if "fromMonth" in request_body else 1
        to_month = int(request_body["toMonth"]) if "toMonth" in request_body else 12
        if from_month > to_month:
            return JsonResponse({"status": 0, "message": "From month can't be later than To month"}, status=400)
        if block_id:
            result = get_current_monthly_temperature(block_id=block_id, from_month=from_month, to_month=to_month)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_monthly_temperature(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_month = int(request_body["fromMonth"]) if "fromMonth" in request_body else 1
        to_month = int(request_body["toMonth"]) if "toMonth" in request_body else 12
        if from_month > to_month:
            return JsonResponse({"status": 0, "message": "From month can't be later than To month"}, status=400)
        if block_id:
            result = get_historic_monthly_temperature(block_id=block_id, from_month=from_month, to_month=to_month)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)



@csrf_exempt
@require_http_methods(['POST'])
def current_weekly_temperature(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "From week can't be later than To week"}, status=400)
        if block_id:
            result = get_current_weekly_temperature(block_id=block_id, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_weekly_temperature(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "From week can't be later than To week"}, status=400)
        if block_id:
            result = get_historic_weekly_temperature(block_id=block_id, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def current_daily_temperature(request):
    year_start_date = f"{current_year}-01-01"
    prev_day = (now() - timedelta(days=1)).strftime("%Y-%m-%d")
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_date = request_body["fromDate"] if "fromDate" in request_body else year_start_date
        to_date = request_body["toDate"] if "toDate" in request_body else prev_day
        if datetime.strptime(from_date, "%Y-%m-%d") > datetime.strptime(to_date, "%Y-%m-%d"):
            return JsonResponse({"status": 0, "message": "From date can't be later than To date, please check"}, status=400)
        if block_id:
            result = get_current_daily_temperature(block_id=block_id, from_date=from_date, to_date=to_date)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_daily_temperature(request):
    year_start_date = f"{current_year}-01-01"
    prev_day = (now() - timedelta(days=1)).strftime("%Y-%m-%d")
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_date = request_body["fromDate"] if "fromDate" in request_body else year_start_date
        to_date = request_body["toDate"] if "toDate" in request_body else prev_day
        if datetime.strptime(from_date, "%Y-%m-%d") > datetime.strptime(to_date, "%Y-%m-%d"):
            return JsonResponse({"status": 0, "message": "From date can't be later than To date, please check"}, status=400)
        if block_id:
            result = get_historic_daily_temperature(block_id=block_id, from_date=from_date, to_date=to_date)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)
