from dotenv import dotenv_values
from pydruid.db import connect
from pydruid.db.exceptions import ProgrammingError
from requests import ConnectionError
import pandas as pd
from django.utils.timezone import now
from datetime import timedelta, datetime
from lookups.lookup_objects import met_week_long, week_list, month_list
from .stats import get_curr_common_stats, is_non_leap_year


env = dict(dotenv_values())
druid = {
    "host": env["DRUID_HOST"],
    "port": env["DRUID_PORT"],
    "path": env["DRUID_PATH"],
    "scheme": env["DRUID_SCHEME"],
}
current_year = now().year
current_year_filter = f""" AND "year"={current_year}"""
past_30year_filter = f""" AND "year">={current_year-30} AND "year"<={current_year-1}"""
current_day = now().day
current_month = now().month
current_week = next(i for i in met_week_long if i["day"] == current_day and i["month"] == current_month)["met_week"]

previous_day = (now() - timedelta(days=1)).day
previous_day_month = (now() - timedelta(days=1)).month


def get_current_monthly_rainfall(**kwargs):
    block_id = kwargs.get("block_id")
    from_month = kwargs.get("from_month")
    to_month = kwargs.get("to_month")
    month_filter = f""" AND "month_num">={from_month} AND "month_num"<={to_month}""" if from_month and to_month else ""
    try:
        # 1. actual available dates
        # use these days to determine the exact date period for the prev 30 years
        date_query = f"""
            SELECT MIN("__time"), MAX("__time") FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{month_filter}
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            date_query_result = pd.DataFrame(connection.execute(date_query), dtype=object).to_records()
        real_start_date = date_query_result[0][1][0:10]
        real_end_date = date_query_result[0][2][0:10]
        days_count = (datetime.strptime(real_end_date, "%Y-%m-%d") - datetime.strptime(real_start_date, "%Y-%m-%d")).days + 1
        start_month_day = real_start_date[5:]
        end_month_day = real_end_date[5:]
        
        # 2. current year monthly values
        query = f"""
            SELECT "month_num", ROUND(SUM("grid_rainfall"), 1), ROUND(AVG("grid_rainfall"), 1) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{month_filter}
            GROUP BY "month_num"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            monthly_rf_vals = [{
                "month": i[1],
                "month_text": list(filter(lambda x: x["id"] == i[1], month_list))[0]["month_text"],
                "rainfall": i[2],
                "mean_rf": i[3]
            } for i in query_result]
            for n, _ in enumerate(monthly_rf_vals):
                monthly_rf_vals[n]["cumulative_rf"] = round((monthly_rf_vals[n]["rainfall"] if n == 0 else monthly_rf_vals[n]["rainfall"] + monthly_rf_vals[n-1]["cumulative_rf"]), 1)
            monthly_rf_stats = get_curr_common_stats(list(map(lambda x: x["rainfall"], monthly_rf_vals)))
        
        # 3. rolling past 30 year
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_rf_vals = []
            for y in range(current_year - 31, current_year - 1):
                if not is_non_leap_year(y):
                    if start_month_day == "02-29": start_month_day = "02-28"
                    if end_month_day == "02-29": end_month_day = "02-28"
                start_date = f"{y}-{start_month_day}"
                end_date = f"{y}-{end_month_day}"

                query = f"""
                    SELECT "year", ROUND(SUM("grid_rainfall"), 1), COUNT(*) FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{start_date}T00:00:00.000Z' AND "__time"<='{end_date}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_rf_vals.append({"year": query_result[1], "rainfall": query_result[2], "day_count": query_result[3]})
            hist_rf_avg = round(sum(list(map(lambda x: x["rainfall"], hist_rf_vals)))/len(hist_rf_vals), 1) if hist_rf_vals else "N/A"

        # 4. send api response
        return {
            "status": 1, 
            "data": {
                "cy_data": {
                    "cy_start_date": real_start_date,
                    "cy_end_date": real_end_date,
                    "days_count": days_count,
                    "monthly_rf_vals": monthly_rf_vals,
                    "monthly_rf_stats": monthly_rf_stats
                },
                "py_data": {
                    "hist_rf_vals": hist_rf_vals,
                    "hist_rf_avg": hist_rf_avg
                }
            }
        }
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_current_weekly_rainfall(**kwargs):
    block_id = kwargs.get("block_id")
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')
    week_filter = f""" AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""
    try:
        # 1. actual available dates
        # use these days to determine the exact date period for the prev 30 years
        date_query = f"""
            SELECT MIN("__time"), MAX("__time") FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{week_filter}
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            date_query_result = pd.DataFrame(connection.execute(date_query), dtype=object).to_records()
        real_start_date = date_query_result[0][1][0:10]
        real_end_date = date_query_result[0][2][0:10]
        days_count = (datetime.strptime(real_end_date, "%Y-%m-%d") - datetime.strptime(real_start_date, "%Y-%m-%d")).days + 1
        start_month_day = real_start_date[5:]
        end_month_day = real_end_date[5:]

        # 2. current year weekly values
        query = f"""
            SELECT "met_week_num", ROUND(SUM("grid_rainfall"), 1), ROUND(AVG("grid_rainfall"), 1) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{week_filter}
            GROUP BY "met_week_num"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            weekly_rf_vals = [{
                "week": i[1],
                "week_text": list(filter(lambda x: x["id"] == i[1], week_list))[0]["week_text"],
                "rainfall": i[2],
                "mean_rf": i[3]
            } for i in query_result]
            for n, _ in enumerate(weekly_rf_vals):
                weekly_rf_vals[n]["cumulative_rf"] = round((weekly_rf_vals[n]["rainfall"] if n == 0 else weekly_rf_vals[n]["rainfall"] + weekly_rf_vals[n-1]["cumulative_rf"]), 1)
            weekly_rf_stats = get_curr_common_stats(list(map(lambda x: x["rainfall"], weekly_rf_vals)))
        
        # 3. rolling past 30 year
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_rf_vals = []
            for y in range(current_year - 31, current_year - 1):
                if not is_non_leap_year(y):
                    if start_month_day == "02-29": start_month_day = "02-28"
                    if end_month_day == "02-29": end_month_day = "02-28"
                start_date = f"{y}-{start_month_day}"
                end_date = f"{y}-{end_month_day}"

                query = f"""
                    SELECT "year", ROUND(SUM("grid_rainfall"), 1), COUNT(*) FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{start_date}T00:00:00.000Z' AND "__time"<='{end_date}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_rf_vals.append({"year": query_result[1], "rainfall": query_result[2], "day_count": query_result[3]})
            hist_rf_avg = round(sum(list(map(lambda x: x["rainfall"], hist_rf_vals)))/len(hist_rf_vals), 1) if hist_rf_vals else "N/A"

        return {
            "status": 1, 
            "data": {
                "cy_data": {
                    "cy_start_date": real_start_date,
                    "cy_end_date": real_end_date,
                    "days_count": days_count,
                    "weekly_rf_vals": weekly_rf_vals,
                    "weekly_rf_stats": weekly_rf_stats
                },
                "py_data": {
                    "hist_rf_vals": hist_rf_vals,
                    "hist_rf_avg": hist_rf_avg
                }
            }
        }
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_current_daily_rainfall(**kwargs):
    block_id = kwargs.get("block_id")
    from_date = kwargs.get("from_date")
    to_date = kwargs.get("to_date")
    date_filter = f""" AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'""" if from_date and to_date else ""
    try:
        # 1. actual available dates
        # use these days to determine the exact date period for the prev 30 years
        date_query = f"""
            SELECT MIN("__time"), MAX("__time") FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{date_filter}
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            date_query_result = pd.DataFrame(connection.execute(date_query), dtype=object).to_records()
        real_start_date = date_query_result[0][1][0:10]
        real_end_date = date_query_result[0][2][0:10]
        days_count = (datetime.strptime(real_end_date, "%Y-%m-%d") - datetime.strptime(real_start_date, "%Y-%m-%d")).days + 1
        start_month_day = real_start_date[5:]
        end_month_day = real_end_date[5:]

        # 2. current year daily values
        query = f"""
            SELECT "__time", ROUND(SUM("grid_rainfall"), 1) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{date_filter}
            GROUP BY "__time"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            daily_rf_vals = [{
                "date": i[1][0:10],
                "day_index": next(x for x in met_week_long if int(i[1][5:7]) == x["month"] and int(i[1][8:10]) == x["day"])["id"],
                "rainfall": i[2],
            } for i in query_result]
            for n, _ in enumerate(daily_rf_vals):
                daily_rf_vals[n]["cumulative_rf"] = round((daily_rf_vals[n]["rainfall"] if n == 0 else daily_rf_vals[n]["rainfall"] + daily_rf_vals[n-1]["cumulative_rf"]), 1)
            daily_rf_stats = get_curr_common_stats(list(map(lambda x: x["rainfall"], daily_rf_vals)))
        
        # 3. rolling past 30 year
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_rf_vals = []
            for y in range(current_year - 31, current_year - 1):
                if not is_non_leap_year(y):
                    if start_month_day == "02-29": start_month_day = "02-28"
                    if end_month_day == "02-29": end_month_day = "02-28"
                start_date = f"{y}-{start_month_day}"
                end_date = f"{y}-{end_month_day}"

                query = f"""
                    SELECT "year", ROUND(SUM("grid_rainfall"), 1), COUNT(*) FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{start_date}T00:00:00.000Z' AND "__time"<='{end_date}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_rf_vals.append({"year": query_result[1], "rainfall": query_result[2], "day_count": query_result[3]})
            hist_rf_avg = round(sum(list(map(lambda x: x["rainfall"], hist_rf_vals)))/len(hist_rf_vals), 1) if hist_rf_vals else "N/A"

        # 4. send api response
        return{
            "status": 1, 
            "data": {
                "cy_data": {
                    "cy_start_date": real_start_date,
                    "cy_end_date": real_end_date,
                    "days_count": days_count,
                    "daily_rf_vals": daily_rf_vals,
                    "daily_rf_stats": daily_rf_stats
                },
                "py_data": {
                    "hist_rf_vals": hist_rf_vals,
                    "hist_rf_avg": hist_rf_avg
                }
            }
        }
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_current_monthly_temperature(**kwargs):
    block_id = kwargs.get("block_id")
    from_month = kwargs.get("from_month")
    to_month = kwargs.get("to_month")
    month_filter = f""" AND "month_num">={from_month} AND "month_num"<={to_month}""" if from_month and to_month else ""
    try:
        # 1. actual available dates
        # use these days to determine the exact date period for the prev 30 years
        date_query = f"""
            SELECT MIN("__time"), MAX("__time") FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{month_filter}
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            date_query_result = pd.DataFrame(connection.execute(date_query), dtype=object).to_records()
        real_start_date = date_query_result[0][1][0:10]
        real_end_date = date_query_result[0][2][0:10]
        days_count = (datetime.strptime(real_end_date, "%Y-%m-%d") - datetime.strptime(real_start_date, "%Y-%m-%d")).days + 1
        start_month_day = real_start_date[5:]
        end_month_day = real_end_date[5:]

        # 2. current year weekly values
        query = f"""
            SELECT "month_num", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{month_filter}
            GROUP BY "month_num"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            monthly_temp_vals = [{
                "month": i[1],
                "month_text": list(filter(lambda x: x["id"] == i[1], month_list))[0]["month_text"],
                "avg_min_temp": i[2],
                "avg_max_temp": i[3],
                "avg_avg_temp": round((i[2]+i[3])/2, 1)
            } for i in query_result]
            monthly_min_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_min_temp"], monthly_temp_vals)))
            monthly_max_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_max_temp"], monthly_temp_vals)))
            monthly_avg_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_avg_temp"], monthly_temp_vals)))
        
        # 3. rolling past 30 year
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_temp_vals = []
            for y in range(current_year - 31, current_year - 1):
                if not is_non_leap_year(y):
                    if start_month_day == "02-29": start_month_day = "02-28"
                    if end_month_day == "02-29": end_month_day = "02-28"
                start_date = f"{y}-{start_month_day}"
                end_date = f"{y}-{end_month_day}"

                query = f"""
                      SELECT "year", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1), COUNT(*) 
                      FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                      AND "year"={y} AND "__time">='{start_date}T00:00:00.000Z' AND "__time"<='{end_date}T00:00:00.000Z'
                      GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_temp_vals.append({"year": query_result[1], "avg_min_temp": query_result[2], "avg_max_temp": query_result[3], "avg_avg_temp": round((query_result[2]+query_result[3])/2, 1), "day_count": query_result[4]})
            hist_min_temp_avg = round(sum(list(map(lambda x: x["avg_min_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_max_temp_avg = round(sum(list(map(lambda x: x["avg_max_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_avg_temp_avg = round(sum(list(map(lambda x: x["avg_avg_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"

        return {
            "status": 1, 
            "data": {
                "cy_data": {
                    "cy_start_date": real_start_date,
                    "cy_end_date": real_end_date,
                    "days_count": days_count,
                    "monthly_temp_vals": monthly_temp_vals,
                    "monthly_min_temp_stats": monthly_min_temp_stats,
                    "monthly_max_temp_stats": monthly_max_temp_stats,
                    "monthly_avg_temp_stats": monthly_avg_temp_stats
                },
                "py_data": {
                    "hist_temp_vals": hist_temp_vals,
                    "hist_min_temp_avg": hist_min_temp_avg,
                    "hist_max_temp_avg": hist_max_temp_avg,
                    "hist_avg_temp_avg": hist_avg_temp_avg
                }
            }
        }
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_current_weekly_temperature(**kwargs):
    block_id = kwargs.get("block_id")
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')
    week_filter = f""" AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""
    try:
        # 1. actual available dates
        # use these days to determine the exact date period for the prev 30 years
        date_query = f"""
            SELECT MIN("__time"), MAX("__time") FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{week_filter}
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            date_query_result = pd.DataFrame(connection.execute(date_query), dtype=object).to_records()
        real_start_date = date_query_result[0][1][0:10]
        real_end_date = date_query_result[0][2][0:10]
        days_count = (datetime.strptime(real_end_date, "%Y-%m-%d") - datetime.strptime(real_start_date, "%Y-%m-%d")).days + 1
        start_month_day = real_start_date[5:]
        end_month_day = real_end_date[5:]

        # 2. current year weekly values
        query = f"""
            SELECT "met_week_num", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{week_filter}
            GROUP BY "met_week_num"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            weekly_temp_vals = [{
                "week": i[1],
                "week_text": list(filter(lambda x: x["id"] == i[1], week_list))[0]["week_text"],
                "avg_min_temp": i[2],
                "avg_max_temp": i[3],
                "avg_avg_temp": round((i[2]+i[3])/2, 1)
            } for i in query_result]
            weekly_min_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_min_temp"], weekly_temp_vals)))
            weekly_max_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_max_temp"], weekly_temp_vals)))
            weekly_avg_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_avg_temp"], weekly_temp_vals)))
        
        # 3. rolling past 30 year
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_temp_vals = []
            for y in range(current_year - 31, current_year - 1):
                if not is_non_leap_year(y):
                    if start_month_day == "02-29": start_month_day = "02-28"
                    if end_month_day == "02-29": end_month_day = "02-28"
                start_date = f"{y}-{start_month_day}"
                end_date = f"{y}-{end_month_day}"

                query = f"""
                      SELECT "year", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1), COUNT(*) 
                      FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                      AND "year"={y} AND "__time">='{start_date}T00:00:00.000Z' AND "__time"<='{end_date}T00:00:00.000Z'
                      GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_temp_vals.append({"year": query_result[1], "avg_min_temp": query_result[2], "avg_max_temp": query_result[3], "avg_avg_temp": round((query_result[2]+query_result[3])/2, 1), "day_count": query_result[4]})
            hist_min_temp_avg = round(sum(list(map(lambda x: x["avg_min_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_max_temp_avg = round(sum(list(map(lambda x: x["avg_max_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_avg_temp_avg = round(sum(list(map(lambda x: x["avg_avg_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"

        return {
            "status": 1, 
            "data": {
                "cy_data": {
                    "cy_start_date": real_start_date,
                    "cy_end_date": real_end_date,
                    "days_count": days_count,
                    "weekly_temp_vals": weekly_temp_vals,
                    "weekly_min_temp_stats": weekly_min_temp_stats,
                    "weekly_max_temp_stats": weekly_max_temp_stats,
                    "weekly_avg_temp_stats": weekly_avg_temp_stats
                },
                "py_data": {
                    "hist_temp_vals": hist_temp_vals,
                    "hist_min_temp_avg": hist_min_temp_avg,
                    "hist_max_temp_avg": hist_max_temp_avg,
                    "hist_avg_temp_avg": hist_avg_temp_avg
                }
            }
        }
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_current_daily_temperature(**kwargs):
    block_id = kwargs.get("block_id")
    from_date = kwargs.get("from_date")
    to_date = kwargs.get("to_date")
    date_filter = f""" AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'""" if from_date and to_date else ""
    try:
        # 1. actual available dates
        # use these days to determine the exact date period for the prev 30 years
        date_query = f"""
            SELECT MIN("__time"), MAX("__time") FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{date_filter}
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            date_query_result = pd.DataFrame(connection.execute(date_query), dtype=object).to_records()
        real_start_date = date_query_result[0][1][0:10]
        real_end_date = date_query_result[0][2][0:10]
        days_count = (datetime.strptime(real_end_date, "%Y-%m-%d") - datetime.strptime(real_start_date, "%Y-%m-%d")).days + 1
        start_month_day = real_start_date[5:]
        end_month_day = real_end_date[5:]

        # 2. current year daily values
        query = f"""
            SELECT "__time", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{current_year_filter}{date_filter}
            GROUP BY "__time"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            daily_temp_vals = [{
                "date": i[1][0:10],
                "day_index": next(x for x in met_week_long if int(i[1][5:7]) == x["month"] and int(i[1][8:10]) == x["day"])["id"],
                "avg_min_temp": i[2],
                "avg_max_temp": i[3],
                "avg_avg_temp": round((i[2]+i[3])/2, 1)
            } for i in query_result]
            daily_min_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_min_temp"], daily_temp_vals)))
            daily_max_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_max_temp"], daily_temp_vals)))
            daily_avg_temp_stats = get_curr_common_stats(list(map(lambda x: x["avg_avg_temp"], daily_temp_vals)))
        
        # 3. rolling past 30 year
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_temp_vals = []
            for y in range(current_year - 31, current_year - 1):
                if not is_non_leap_year(y):
                    if start_month_day == "02-29": start_month_day = "02-28"
                    if end_month_day == "02-29": end_month_day = "02-28"
                start_date = f"{y}-{start_month_day}"
                end_date = f"{y}-{end_month_day}"

                query = f"""
                      SELECT "year", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1), COUNT(*) 
                      FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                      AND "year"={y} AND "__time">='{start_date}T00:00:00.000Z' AND "__time"<='{end_date}T00:00:00.000Z'
                      GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_temp_vals.append({"year": query_result[1], "avg_min_temp": query_result[2], "avg_max_temp": query_result[3], "avg_avg_temp": round((query_result[2]+query_result[3])/2, 1), "day_count": query_result[4]})
            hist_min_temp_avg = round(sum(list(map(lambda x: x["avg_min_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_max_temp_avg = round(sum(list(map(lambda x: x["avg_max_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_avg_temp_avg = round(sum(list(map(lambda x: x["avg_avg_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
        
        return {
            "status": 1, 
            "data": {
                "cy_data": {
                    "cy_start_date": real_start_date,
                    "cy_end_date": real_end_date,
                    "days_count": days_count,
                    "daily_temp_vals": daily_temp_vals,
                    "daily_min_temp_stats": daily_min_temp_stats,
                    "daily_max_temp_stats": daily_max_temp_stats,
                    "daily_avg_temp_stats": daily_avg_temp_stats
                },
                "py_data": {
                    "hist_temp_vals": hist_temp_vals,
                    "hist_min_temp_avg": hist_min_temp_avg,
                    "hist_max_temp_avg": hist_max_temp_avg,
                    "hist_avg_temp_avg": hist_avg_temp_avg
                }
            }
        }
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}



# Redundant historic -- irrespective of dates, takes start and end date of selection

def get_historic_monthly_rainfall(**kwargs):
    block_id = kwargs.get("block_id")
    from_month = kwargs.get("from_month")
    to_month = kwargs.get("to_month")
    try:
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_rf_vals = []
            for y in range(current_year-30, current_year):
                from_date = f"{y}-{str(from_month).zfill(2)}-01"                
                to_day = "28" if to_month == 2 and previous_day == 29 and is_non_leap_year(y) else str(previous_day).zfill(2)
                to_mth = str(previous_day_month).zfill(2)
                to_date = f"{y}-{to_mth}-{to_day}"

                query = f"""
                    SELECT "year", ROUND(SUM("grid_rainfall"), 1), COUNT(*) FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_rf_vals.append({"year": query_result[1], "rainfall": query_result[2], "day_count": query_result[3]})
            
            hist_rf_avg = round(sum(list(map(lambda x: x["rainfall"], hist_rf_vals)))/len(hist_rf_vals), 1) if hist_rf_vals else "N/A"
            return {"status": 1, "data": {
                "hist_rf_vals": hist_rf_vals,
                "hist_rf_avg": hist_rf_avg
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_weekly_rainfall(**kwargs):
    block_id = kwargs.get("block_id")
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')
    try:
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_rf_vals = []
            for y in range(current_year-30, current_year):
                from_week_days = list(filter(lambda x: x["met_week"] == from_week, met_week_long))
                from_week_start = from_week_days[0]

                from_month = str(from_week_start["month"]).zfill(2)
                from_day = str(from_week_start["day"]).zfill(2)
                from_date = f"{y}-02-28" if is_non_leap_year(y) and from_month == "02" and from_day == "29" else f"{y}-{from_month}-{from_day}"
                
                to_week_days = list(filter(lambda x: x["met_week"] == to_week, met_week_long))
                to_week_end = to_week_days[-1]
                to_month = str(previous_day_month).zfill(2) if to_week >= current_week else str(to_week_end["month"]).zfill(2)
                to_day = str(previous_day).zfill(2) if to_week >= current_week else str(to_week_end["day"]).zfill(2)
                to_date = f"{y}-02-28" if is_non_leap_year(y) and to_month == "02" and to_day == "29" else  f"{y}-{to_month}-{to_day}"
                
                query = f"""
                    SELECT "year", ROUND(SUM("grid_rainfall"), 1), COUNT(*) FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_rf_vals.append({"year": query_result[1], "rainfall": query_result[2], "day_count": query_result[3]})
            
            hist_rf_avg = round(sum(list(map(lambda x: x["rainfall"], hist_rf_vals)))/len(hist_rf_vals), 1) if hist_rf_vals else "N/A"
            return {"status": 1, "data": {
                "hist_rf_vals": hist_rf_vals,
                "hist_rf_avg": hist_rf_avg
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_daily_rainfall(**kwargs):
    block_id = kwargs.get("block_id")
    from_date = kwargs.get("from_date")
    to_date = kwargs.get("to_date")
    try:
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_rf_vals = []
            for y in range(current_year-30, current_year):
                from_month = from_date[5:7]
                from_day = from_date[8:10]
                from_dt = f"{y}-02-28" if from_month == "02" and from_day == "29" and is_non_leap_year(y) else f"{y}-{from_month}-{from_day}"
                to_month = to_date[5:7]
                to_day = to_date[8:10]
                to_dt = f"{y}-02-28" if to_month == "02" and to_day == "29" and is_non_leap_year(y) else f"{y}-{to_month}-{to_day}"
                query = f"""
                    SELECT "year", ROUND(SUM("grid_rainfall"), 1), COUNT(*) FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{from_dt}T00:00:00.000Z' AND "__time"<='{to_dt}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_rf_vals.append({"year": query_result[1], "rainfall": query_result[2], "day_count": query_result[3]})
            hist_rf_avg = round(sum(list(map(lambda x: x["rainfall"], hist_rf_vals)))/len(hist_rf_vals), 1) if hist_rf_vals else "N/A"
            return {"status": 1, "data": {
                "hist_rf_vals": hist_rf_vals,
                "hist_rf_avg": hist_rf_avg
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_monthly_temperature(**kwargs):
    block_id = kwargs.get("block_id")
    from_month = kwargs.get("from_month")
    to_month = kwargs.get("to_month")
    try:
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_temp_vals = []
            for y in range(current_year-30, current_year):
                from_date = f"{y}-{str(from_month).zfill(2)}-01"                
                to_day = "28" if to_month == 2 and previous_day == 29 and is_non_leap_year(y) else str(previous_day).zfill(2)
                to_mth = str(previous_day_month).zfill(2)
                to_date = f"{y}-{to_mth}-{to_day}"

                query = f"""
                      SELECT "year", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1), COUNT(*) 
                      FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                      AND "year"={y} AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'
                      GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_temp_vals.append({"year": query_result[1], "avg_min_temp": query_result[2], "avg_max_temp": query_result[3], "avg_avg_temp": round((query_result[2]+query_result[3])/2, 1), "day_count": query_result[4]})
            
            hist_min_temp_avg = round(sum(list(map(lambda x: x["avg_min_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_max_temp_avg = round(sum(list(map(lambda x: x["avg_max_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_avg_temp_avg = round(sum(list(map(lambda x: x["avg_avg_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            return {"status": 1, "data": {
                "hist_temp_vals": hist_temp_vals,
                "hist_min_temp_avg": hist_min_temp_avg,
                "hist_max_temp_avg": hist_max_temp_avg,
                "hist_avg_temp_avg": hist_avg_temp_avg
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_weekly_temperature(**kwargs):
    block_id = kwargs.get("block_id")
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')
    try:
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_temp_vals = []
            for y in range(current_year-30, current_year):
                from_week_days = list(filter(lambda x: x["met_week"] == from_week, met_week_long))
                from_week_start = from_week_days[0]

                from_month = str(from_week_start["month"]).zfill(2)
                from_day = str(from_week_start["day"]).zfill(2)
                from_date = f"{y}-02-28" if is_non_leap_year(y) and from_month == "02" and from_day == "29" else f"{y}-{from_month}-{from_day}"
                
                to_week_days = list(filter(lambda x: x["met_week"] == to_week, met_week_long))
                to_week_end = to_week_days[-1]
                to_month = str(previous_day_month).zfill(2) if to_week >= current_week else str(to_week_end["month"]).zfill(2)
                to_day = str(previous_day).zfill(2) if to_week >= current_week else str(to_week_end["day"]).zfill(2)
                to_date = f"{y}-02-28" if is_non_leap_year(y) and to_month == "02" and to_day == "29" else  f"{y}-{to_month}-{to_day}"
                
                query = f"""
                    SELECT "year", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1), COUNT(*) 
                    FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_temp_vals.append({"year": query_result[1], "avg_min_temp": query_result[2], "avg_max_temp": query_result[3], "avg_avg_temp": round((query_result[2]+query_result[3])/2, 1), "day_count": query_result[4]})
            
            hist_min_temp_avg = round(sum(list(map(lambda x: x["avg_min_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_max_temp_avg = round(sum(list(map(lambda x: x["avg_max_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_avg_temp_avg = round(sum(list(map(lambda x: x["avg_avg_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            return {"status": 1, "data": {
                "hist_temp_vals": hist_temp_vals,
                "hist_min_temp_avg": hist_min_temp_avg,
                "hist_max_temp_avg": hist_max_temp_avg,
                "hist_avg_temp_avg": hist_avg_temp_avg
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_daily_temperature(**kwargs):
    block_id = kwargs.get("block_id")
    from_date = kwargs.get("from_date")
    to_date = kwargs.get("to_date")
    try:
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            hist_temp_vals = []
            for y in range(current_year-30, current_year):
                from_month = from_date[5:7]
                from_day = from_date[8:10]
                from_dt = f"{y}-02-28" if from_month == "02" and from_day == "29" and is_non_leap_year(y) else f"{y}-{from_month}-{from_day}"
                to_month = to_date[5:7]
                to_day = to_date[8:10]
                to_dt = f"{y}-02-28" if to_month == "02" and to_day == "29" and is_non_leap_year(y) else f"{y}-{to_month}-{to_day}"
                query = f"""
                    SELECT "year", ROUND(AVG("grid_temp_min"), 1), ROUND(AVG("grid_temp_max"), 1), COUNT(*) FROM "druid"."grid-rainfall-data" WHERE 1=1 AND block_id={block_id} 
                    AND "year"={y} AND "__time">='{from_dt}T00:00:00.000Z' AND "__time"<='{to_dt}T00:00:00.000Z'
                    GROUP BY "year"
                """
                query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()[0]
                hist_temp_vals.append({"year": query_result[1], "avg_min_temp": query_result[2], "avg_max_temp": query_result[3], "avg_avg_temp": round((query_result[2]+query_result[3])/2, 1), "day_count": query_result[4]})
            hist_min_temp_avg = round(sum(list(map(lambda x: x["avg_min_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_max_temp_avg = round(sum(list(map(lambda x: x["avg_max_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            hist_avg_temp_avg = round(sum(list(map(lambda x: x["avg_avg_temp"], hist_temp_vals)))/len(hist_temp_vals), 1) if hist_temp_vals else "N/A"
            return {"status": 1, "data": {
                "hist_temp_vals": hist_temp_vals,
                "hist_min_temp_avg": hist_min_temp_avg,
                "hist_max_temp_avg": hist_max_temp_avg,
                "hist_avg_temp_avg": hist_avg_temp_avg
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}

