from django.urls import path
from . import views

urlpatterns = [
    # RAINFALL
    # Monthly
    path('current_monthly_rainfall', views.current_monthly_rainfall, name='current_monthly_rainfall'),
    path('historic_monthly_rainfall', views.historic_monthly_rainfall, name='historic_monthly_rainfall'),
    # Weekly
    path('current_weekly_rainfall', views.current_weekly_rainfall, name='current_weekly_rainfall'),
    path('historic_weekly_rainfall', views.historic_weekly_rainfall, name='historic_weekly_rainfall'),
    # Daily
    path('current_daily_rainfall', views.current_daily_rainfall, name='current_daily_rainfall'),
    path('historic_daily_rainfall', views.historic_daily_rainfall, name='historic_daily_rainfall'),
    # TEMPERATURE
    # Monthly
    path('current_monthly_temperature', views.current_monthly_temperature, name='current_monthly_temperature'),
    path('historic_monthly_temperature', views.historic_monthly_temperature, name='historic_monthly_temperature'),
    # Weekly
    path('current_weekly_temperature', views.current_weekly_temperature, name='current_weekly_temperature'),
    path('historic_weekly_temperature', views.historic_weekly_temperature, name='historic_weekly_temperature'),
    # Daily
    path('current_daily_temperature', views.current_daily_temperature, name='current_daily_temperature'),
    path('historic_daily_temperature', views.historic_daily_temperature, name='historic_daily_temperature'),

]
