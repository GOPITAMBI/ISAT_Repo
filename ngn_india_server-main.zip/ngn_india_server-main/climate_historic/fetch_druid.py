from dotenv import dotenv_values
from pydruid.db import connect
from pydruid.db.exceptions import ProgrammingError
from requests import ConnectionError
import pandas as pd
from django.utils.timezone import now
from lookups.lookup_objects import week_list, crop_list
from .stats import rf_range_check, get_hist_rf_common_stats, get_hist_rf_poe, \
    get_hist_temp_common_stats, temp_range_check


env = dict(dotenv_values())
druid = {
    "host": env["DRUID_HOST"],
    "port": env["DRUID_PORT"],
    "path": env["DRUID_PATH"],
    "scheme": env["DRUID_SCHEME"],
}
current_year = now().year

# 1. Rainfall - Start

def get_historic_yearly_rainfall(**kwargs):
    block_id = kwargs.get('block_id')
    rf_gte = kwargs.get('rf_gte')
    rf_lt = kwargs.get('rf_lt')
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')
    from_month = kwargs.get('from_month')
    to_month = kwargs.get('to_month')
    from_date = kwargs.get('from_date')
    to_date = kwargs.get('to_date')

    year_filter = f""" AND "year" >= {current_year-30} AND "year" <= {current_year-1}"""
    week_filter = f""" AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""
    month_filter = f""" AND "month_num">={from_month} AND "month_num"<={to_month}""" if from_month and to_month else ""
    date_filter = f""" AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'""" if from_date and to_date else ""

    try:
        query = f"""
            SELECT "year", "year_type", ROUND(SUM("grid_rainfall"), 0) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{year_filter}{month_filter}{week_filter}{date_filter} 
            GROUP BY "year", "year_type"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            # YEARLY VALUES
            all_year_rf_vals = [{
                "year": i[1], "year_type": i[2], "rainfall": int(i[3]),
                "range_match": rf_range_check(i[3], rf_gte, rf_lt)} for i in query_result]
            elnino_year_rf_vals = [{"year": i["year"], "year_type_match": True if i["year_type"] == "El Niño" else False,
                                    "rainfall": i["rainfall"], "range_match": rf_range_check(i["rainfall"], rf_gte, rf_lt)
                                    } for i in all_year_rf_vals]
            lanina_year_rf_vals = [{"year": i["year"], "year_type_match": True if i["year_type"] == "La Niña" else False,
                                    "rainfall": i["rainfall"], "range_match": rf_range_check(i["rainfall"], rf_gte, rf_lt)
                                    } for i in all_year_rf_vals]
            # YEARLY STATS
            all_year_rf_stats = get_hist_rf_common_stats(all_year_rf_vals)
            all_years_poe = get_hist_rf_poe(all_year_rf_vals)
            elnino_year_rf_stats = get_hist_rf_common_stats(elnino_year_rf_vals)
            elnino_years_poe = get_hist_rf_poe(elnino_year_rf_vals)
            lanina_year_rf_stats = get_hist_rf_common_stats(lanina_year_rf_vals)
            lanina_years_poe = get_hist_rf_poe(lanina_year_rf_vals)
            data = {
                "all_years_rf_vals": all_year_rf_vals,
                "all_years_rf_stats": all_year_rf_stats,
                "all_years_poe": all_years_poe,
                "elnino_year_rf_vals": elnino_year_rf_vals,
                "elnino_year_rf_stats": elnino_year_rf_stats,
                "elnino_years_poe": elnino_years_poe,
                "lanina_year_rf_vals": lanina_year_rf_vals,
                "lanina_year_rf_stats": lanina_year_rf_stats,
                "lanina_years_poe": lanina_years_poe,
                "total_year_count": len(all_year_rf_vals)
            }
            return {"status": 1, "data": data}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_dry_spells(**kwargs):
    block_id = kwargs.get('block_id')
    rf_lt = kwargs.get('rf_lt')
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')

    week_filter = f"""AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""

    try:
        query = f"""
            SELECT "year", "met_week_num", ROUND(SUM("grid_rainfall"), 1), "year_type" FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "year" >= {current_year-30} AND "year" <= {current_year-1} AND "block_id"={block_id} {week_filter}
            GROUP BY "year","met_week_num", "year_type"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            week_year_rf_vals = [{
                "year": i[1], "week": i[2], "rainfall": float(i[3]), "enso": i[4],
                "range_match": rf_range_check(i[3], rf_gte=None, rf_lt=rf_lt)} for i in query_result]
            total_years = len(list(set(map(lambda x: x["year"], week_year_rf_vals))))
            week_rf_probabilities = []
            for wk in range(from_week, to_week+1):
                matched_years = len(list(filter(lambda x: x["range_match"] and x["week"] == wk, week_year_rf_vals)))
                week_rf_probabilities.append({
                    "week": wk, "week_text": next((i for i in week_list if i["id"] == wk))["week_text"],  
                    "probability": round((matched_years*100)/total_years, 2)
                })
            return {"status": 1, "data": {
                "week_year_rf_vals": week_year_rf_vals,
                "week_rf_probabilities": week_rf_probabilities
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except (IndexError, ZeroDivisionError):
        return {"status": 0, "message": "No results for selected block/block ID"}


def get_historic_wet_spells(**kwargs):
    block_id = kwargs.get('block_id')
    rf_gte = kwargs.get('rf_gte')
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')

    week_filter = f"""AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""

    try:
        query = f"""
            SELECT "year", "met_week_num", ROUND(SUM("grid_rainfall"), 1), "year_type" FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "year" >= {current_year-30} AND "year" <= {current_year-1} AND "block_id"={block_id} {week_filter}
            GROUP BY "year","met_week_num", "year_type"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            week_year_rf_vals = [{
                "year": i[1], "week": i[2], "rainfall": float(i[3]), "enso": i[4],
                "range_match": rf_range_check(i[3], rf_gte=rf_gte, rf_lt=None)} for i in query_result]
            total_years = len(list(set(map(lambda x: x["year"], week_year_rf_vals))))
            week_rf_probabilities = []
            for wk in range(from_week, to_week+1):
                matched_years = len(list(filter(lambda x: x["range_match"] and x["week"] == wk, week_year_rf_vals)))
                week_rf_probabilities.append({
                    "week": wk, "week_text": next((i for i in week_list if i["id"] == wk))["week_text"],  
                    "probability": round((matched_years*100)/total_years, 2)
                })
            return {"status": 1, "data": {
                "week_year_rf_vals": week_year_rf_vals,
                "week_rf_probabilities": week_rf_probabilities
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except (IndexError, ZeroDivisionError):
        return {"status": 0, "message": "No results for selected block/block ID"}


def get_historic_crop_stress(**kwargs):
    crop_id = kwargs.get('crop_id')
    block_id = kwargs.get('block_id')
    rf_gte = kwargs.get('rf_gte')
    from_week = kwargs.get('from_week')
    stress_probability = kwargs.get('stress_probability')

    try:
        query = f"""
            SELECT "year", "met_week_num", ROUND(SUM("grid_rainfall"), 1) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "year" >= {current_year - 30} AND "year" <= {current_year - 1} AND "block_id"={block_id}
            GROUP BY "year", "met_week_num"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            week_year_rf_vals = [{
                "year": i[1], "week": i[2], "rainfall": float(i[3]),
                "range_match": rf_range_check(i[3], rf_gte=rf_gte, rf_lt=None)} for i in query_result]
            all_year_list = list(set(map(lambda x: x["year"], week_year_rf_vals)))
            total_years = len(all_year_list)
            all_week_rf_probabilities = []
            for wk in range(1, 53):
                matched_years = len(list(filter(lambda x: x["range_match"] and x["week"] == wk, week_year_rf_vals)))
                week_across_years = list(filter(lambda x: x["week"] == wk, week_year_rf_vals))
                weekrf_across_years = list(map (lambda x: x["rainfall"], week_across_years))
                all_week_rf_probabilities.append({
                    "week": wk, 
                    "week_text": next((i for i in week_list if i["id"] == wk))["week_text"],
                    "avg_rainfall": round(sum(weekrf_across_years)/(len(weekrf_across_years) or 1)),    # average rainfall for that week
                    "probability": round((matched_years*100)/ total_years, 2)
                })

            crop_obj = list(filter(lambda x: x["id"] == crop_id, crop_list))[0]
            sowing_weeks = crop_obj["sowing_weeks"]
            # week_threshold = crop_obj["threshold_percentage"]
            week_threshold = stress_probability
            sowing_stages = crop_obj["sowing_stages"]
            week_rf_probabilities = list(filter(lambda x: from_week <= x["week"] < from_week+sowing_weeks, all_week_rf_probabilities))
            if len(week_rf_probabilities) < 15:
                week_rf_probabilities += list(filter(lambda x: x["week"] <= sowing_weeks-len(week_rf_probabilities), all_week_rf_probabilities))
            n = 1
            for i in week_rf_probabilities:
                i["week_index"] = n
                i["prob_match"] = True if i["probability"] >= week_threshold else False
                n += 1
            for stage in sowing_stages:
                for prob in week_rf_probabilities:
                    if prob["week_index"] in range(stage["from"], stage["to"]+1):
                        prob["stage"] = stage["stage"]

            # Here add from start date of start week to end date of end week
            data = {"week_rf_probabilities": week_rf_probabilities, "threshold": week_threshold}
            data["suggested_varieties"] = crop_obj["suggested_varieties"]
            cumulative_rf_gte = rf_gte * sowing_weeks
            data["cumulative_rf_gte"] = cumulative_rf_gte
            uq_weeks = list(map(lambda x: x["week"], week_rf_probabilities))
            total_period_rfs = []
            for y in all_year_list:
                wy_filtered = list(filter(lambda x: x["year"] == y and x["week"] in uq_weeks, week_year_rf_vals))
                wy_vals = list(map(lambda m: m["rainfall"], wy_filtered))
                total_period_rfs.append(sum(wy_vals))
            average_period_rf = sum(total_period_rfs)/(len(total_period_rfs) or 1)
            total_period_probability = len(list(filter(lambda x: cumulative_rf_gte < x, total_period_rfs))) * 100/len(total_period_rfs)
            data["average_period_rf"] = average_period_rf
            data["total_period_probability"] = round(total_period_probability, 2)
            return {"status": 1, "data": data}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except (IndexError, ZeroDivisionError):
        return {"status": 0, "message": "No results for selected block/block ID"}


# 1. Rainfall - End


# 2. Temperature - Start

def get_historic_yearly_temperature(**kwargs):
    block_id = kwargs.get('block_id')
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')
    from_month = kwargs.get('from_month')
    to_month = kwargs.get('to_month')
    from_date = kwargs.get('from_date')
    to_date = kwargs.get('to_date')

    year_filter = f""" AND "year" >= {current_year-30} AND "year" <= {current_year-1}"""
    week_filter = f""" AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""
    month_filter = f""" AND "month_num">={from_month} AND "month_num"<={to_month}""" if from_month and to_month else ""
    date_filter = f""" AND "__time">='{from_date}T00:00:00.000Z' AND "__time"<='{to_date}T00:00:00.000Z'""" if from_date and to_date else ""

    try:
        query = f"""
            SELECT "year", ROUND(AVG("grid_temp_max"), 2), ROUND(AVG("grid_temp_min"), 2), ROUND(AVG(("grid_temp_max"+"grid_temp_min")/2), 2)
            FROM "druid"."grid-rainfall-data" 
            WHERE 1=1 AND "block_id"={block_id}{year_filter}{month_filter}{week_filter}{date_filter} 
            GROUP BY "year"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            yearly_temps = [{"year": i[1], "max_temp": i[2], "min_temp": i[3], "avg_temp": i[4]} for i in query_result]
            min_temp_stats = get_hist_temp_common_stats(list(map(lambda x: x["min_temp"], yearly_temps)))
            max_temp_stats = get_hist_temp_common_stats(list(map(lambda x: x["max_temp"], yearly_temps)))
            avg_temp_stats = get_hist_temp_common_stats(list(map(lambda x: x["avg_temp"], yearly_temps)))
            data = {
                "yearly_temps": yearly_temps,
                "min_temp_stats": min_temp_stats,
                "max_temp_stats": max_temp_stats,
                "avg_temp_stats": avg_temp_stats
            }
            return {"status": 1, "data": data}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_hot_spells(**kwargs):
    block_id = kwargs.get('block_id')
    temp_gte = kwargs.get('temp_gte')
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')

    year_filter = f""" AND "year" >= {current_year-30} AND "year" <= {current_year-1}"""
    week_filter = f""" AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""

    try:
        query = f"""
            SELECT "year", "met_week_num", ROUND(AVG("grid_temp_max"), 2) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{year_filter}{week_filter} GROUP BY "year", "met_week_num"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            weekly_temp_vals = [{"year": i[1], "week": i[2], "max_temp": i[3], "range_match": temp_range_check(i[3], temp_gte=temp_gte, temp_lt=None)} for i in query_result]
            total_years = len(list(set(map(lambda x: x["year"], weekly_temp_vals))))
            weekly_temp_probabilities = []
            for wk in range(from_week, to_week+1):
                matched_years = len(list(filter(lambda x: x["range_match"] and x["week"] == wk, weekly_temp_vals)))
                weekly_temp_probabilities.append({
                    "week": wk, "week_text": next((i for i in week_list if i["id"] == wk))["week_text"],  
                    "probability": round((matched_years*100)/total_years, 2)
                })
            return {"status": 1, "data": {
                "weekly_temp_vals": weekly_temp_vals,
                "weekly_temp_probabilities": weekly_temp_probabilities
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


def get_historic_cold_spells(**kwargs):
    block_id = kwargs.get('block_id')
    temp_lt = kwargs.get('temp_lt')
    from_week = kwargs.get('from_week')
    to_week = kwargs.get('to_week')

    year_filter = f""" AND "year" >= {current_year-30} AND "year" <= {current_year-1}"""
    week_filter = f""" AND "met_week_num">={from_week} AND "met_week_num"<={to_week}""" if from_week and to_week else ""

    try:
        query = f"""
            SELECT "year", "met_week_num", ROUND(AVG("grid_temp_min"), 2) FROM "druid"."grid-rainfall-data"
            WHERE 1=1 AND "block_id"={block_id}{year_filter}{week_filter} GROUP BY "year", "met_week_num"
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query_result = pd.DataFrame(connection.execute(query), dtype=object).to_records()
            weekly_temp_vals = [{"year": i[1], "week": i[2], "min_temp": i[3], "range_match": temp_range_check(i[3], temp_gte=None, temp_lt=temp_lt)} for i in query_result]
            total_years = len(list(set(map(lambda x: x["year"], weekly_temp_vals))))
            weekly_temp_probabilities = []
            for wk in range(from_week, to_week+1):
                matched_years = len(list(filter(lambda x: x["range_match"] and x["week"] == wk, weekly_temp_vals)))
                weekly_temp_probabilities.append({
                    "week": wk, "week_text": next((i for i in week_list if i["id"] == wk))["week_text"],  
                    "probability": round((matched_years*100)/total_years, 2)
                })
            return {"status": 1, "data": {
                "weekly_temp_vals": weekly_temp_vals,
                "weekly_temp_probabilities": weekly_temp_probabilities
            }}
    except ProgrammingError:
        return {"status": 0, "message": "Error in query, please rectify"}
    except ConnectionError:
        return {"status": 0, "message": "Couldn't connect to imd-druid database"}
    except IndexError:
        return {"status": 0, "message": "No results for selected block"}


# 2. Temperature - End
