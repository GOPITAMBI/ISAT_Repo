from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from .fetch_druid import current_year, \
    get_historic_yearly_rainfall, get_historic_dry_spells, get_historic_wet_spells, get_historic_crop_stress, \
    get_historic_yearly_temperature, get_historic_hot_spells, get_historic_cold_spells
from datetime import datetime


@csrf_exempt
@require_http_methods(['POST'])
def historic_yearly_rainfall(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        rf_gte = int(request_body["rfGte"]) if "rfGte" in request_body else 0
        rf_lt = int(request_body["rfLt"]) if "rfLt" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        from_month = int(request_body["fromMonth"]) if "fromMonth" in request_body else 1
        to_month = int(request_body["toMonth"]) if "toMonth" in request_body else 12
        from_date = request_body["fromDate"] if "fromDate" in request_body else f"{current_year-30}-01-01"
        to_date = request_body["toDate"] if "toDate" in request_body else f"{current_year-1}-12-31"
        
        if (rf_gte and rf_lt and rf_gte > rf_lt) or rf_gte < 0 or rf_lt < 0:
            return JsonResponse({"status": 0, "message": "Rainfall limits are invalid, please check"}, status=400)
        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "Met week order is invalid, please check"}, status=400)
        if from_month > to_month:
            return JsonResponse({"status": 0, "message": "Month order is invalid, please check"}, status=400)
        if datetime.strptime(from_date, "%Y-%m-%d") > datetime.strptime(to_date, "%Y-%m-%d"):
            return JsonResponse({"status": 0, "message": "From date can't be later than To date, please check"}, status=400)
        if block_id:
            result = get_historic_yearly_rainfall(block_id=block_id, rf_gte=rf_gte, rf_lt=rf_lt,
                                                    from_week=from_week, to_week=to_week, 
                                                    from_month=from_month, to_month=to_month,
                                                    from_date=from_date, to_date=to_date)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_dry_spells(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        rf_lt = int(request_body["rfLt"]) if "rfLt" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        
        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "Met week order is invalid, please check"}, status=400)
        if block_id and rf_lt:
            result = get_historic_dry_spells(block_id=block_id, rf_lt=rf_lt, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status=200) if result["status"] else JsonResponse(result, status=500)
        else:
            return JsonResponse({"status": 0, "message": "Block and week-rainfall input (<) is required."}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_wet_spells(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        rf_gte = int(request_body["rfGte"]) if "rfGte" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        
        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "Met week order is invalid, please check"}, status=400)
        if block_id and rf_gte:
            result = get_historic_wet_spells(block_id=block_id, rf_gte=rf_gte, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status=200) if result["status"] else JsonResponse(result, status=500)
        else:
            return JsonResponse({"status": 0, "message": "Block and week-rainfall input (>=) is required."}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_crop_stress(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        crop_id = int(request_body["cropId"]) if "cropId" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 0
        rf_gte = int(request_body["rfGte"]) if "rfGte" in request_body else 0
        stress_probability = float(request_body["stressProbability"]) if "stressProbability" in request_body else 0
        if block_id and rf_gte and crop_id and from_week and stress_probability:
            result = get_historic_crop_stress(block_id=block_id, crop_id=crop_id, from_week=from_week, rf_gte=rf_gte, stress_probability=stress_probability)
            return JsonResponse(result, status=200) if result["status"] else JsonResponse(result, status=500)
        else:
            return JsonResponse({"status": 0, "message": "Block, week-rainfall threshold (<), crop, sowing week, stress probability are required"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_yearly_temperature(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52
        from_month = int(request_body["fromMonth"]) if "fromMonth" in request_body else 1
        to_month = int(request_body["toMonth"]) if "toMonth" in request_body else 12
        from_date = request_body["fromDate"] if "fromDate" in request_body else f"{current_year-30}-01-01"
        to_date = request_body["toDate"] if "toDate" in request_body else f"{current_year-1}-12-31"

        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "Met week order is invalid, please check"}, status=400)
        if from_month > to_month:
            return JsonResponse({"status": 0, "message": "Month order is invalid, please check"}, status=400)
        if datetime.strptime(from_date, "%Y-%m-%d") > datetime.strptime(to_date, "%Y-%m-%d"):
            return JsonResponse({"status": 0, "message": "From date can't be later than To date, please check"}, status=400)
        if block_id:
            result = get_historic_yearly_temperature(block_id=block_id,
                                                from_week=from_week, to_week=to_week, 
                                                from_month=from_month, to_month=to_month,
                                                from_date=from_date, to_date=to_date)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_hot_spells(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        temp_gte = int(request_body["tempGte"]) if "tempGte" in request_body else None
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52

        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "Met week order is invalid, please check"}, status=400)
        if block_id and temp_gte:
            result = get_historic_hot_spells(block_id=block_id, temp_gte=temp_gte, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status=200) if result["status"] else JsonResponse(result, status=500)
        else:
            return JsonResponse({"status": 0, "message": "Block and max temperature threshold (>=) are required"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)


@csrf_exempt
@require_http_methods(['POST'])
def historic_cold_spells(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        temp_lt = int(request_body["tempLt"]) if "tempLt" in request_body else None
        from_week = int(request_body["fromWeek"]) if "fromWeek" in request_body else 1
        to_week = int(request_body["toWeek"]) if "toWeek" in request_body else 52

        if from_week > to_week:
            return JsonResponse({"status": 0, "message": "Met week order is invalid, please check"}, status=400)
        if block_id and temp_lt:
            result = get_historic_cold_spells(block_id=block_id, temp_lt=temp_lt, from_week=from_week, to_week=to_week)
            return JsonResponse(result, status=200) if result["status"] else JsonResponse(result, status=500)
        else:
            return JsonResponse({"status": 0, "message": "Block and min temperature threshold (<) are required"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)
