from django.apps import AppConfig


class ClimateHistoricConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'climate_historic'
