from django.urls import path
from . import views


urlpatterns = [
    # RAINFALL
    path('historic_yearly_rainfall', views.historic_yearly_rainfall, name='historic_yearly_rainfall'),
    path('historic_dry_spells', views.historic_dry_spells, name='historic_dry_spells'),
    path('historic_wet_spells', views.historic_wet_spells, name='historic_wet_spells'),
    path('historic_crop_stress', views.historic_crop_stress, name='historic_crop_stress'),
    # TEMPERATURE
    path('historic_yearly_temperature', views.historic_yearly_temperature, name='historic_yearly_temperature'),
    path('historic_hot_spells', views.historic_hot_spells, name='historic_hot_spells'),
    path('historic_cold_spells', views.historic_cold_spells, name='historic_cold_spells'),
]
