from dotenv import dotenv_values
from pydruid.db import connect
from pydruid.db.exceptions import ProgrammingError
from requests import post
from requests import ConnectionError
from json import JSONDecodeError
import pandas as pd
from django.utils.timezone import now
from datetime import timedelta, datetime, date
from lookups.lookup_objects import met_week_long, week_list, month_list


env = dict(dotenv_values())
druid = {
    "host": env["DRUID_HOST"],
    "port": env["DRUID_PORT"],
    "path": env["DRUID_PATH"],
    "scheme": env["DRUID_SCHEME"],
}
current_year = now().year
current_year_filter = f""" AND "year"={current_year}"""
past_30year_filter = f""" AND "year">={current_year-30} AND "year"<={current_year-1}"""
current_day = now().day
current_month = now().month
current_week = next(i for i in met_week_long if i["day"] == current_day and i["month"] == current_month)["met_week"]

previous_day = (now() - timedelta(days=1)).day
previous_day_month = (now() - timedelta(days=1)).month

def get_advisory(**kwargs):
    # ALONG WITH RAINFALL, TEMPERATURE AND RH
    block_id = kwargs.get('block_id')
    
    since_jun1 = {}
    try:
        query1 = f"""
            SELECT ROUND(SUM("grid_rainfall"), 2), ROUND(AVG("grid_temp_max"), 2), ROUND(AVG("grid_temp_min"), 2)
            FROM "druid"."grid-rainfall-data" WHERE "block_id"={block_id}
            AND "__time">='{current_year}-06-01T00:00:00.000Z'
            AND "__time"<='{(date.today() - timedelta(days=1)).strftime("%Y-%m-%d")}T00:00:00.000Z'
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query1_result = pd.DataFrame(connection.execute(query1), dtype=object).to_records()
            print("q1", query1_result)
            if query1_result:
                since_jun1.update({"rainfall": query1_result[0][1], "max_temp": query1_result[0][2], "min_temp": query1_result[0][3]})
            else:
                since_jun1.update({"rainfall": None, "max_temp": None, "min_temp": None})
    except ProgrammingError:
        return {"status": 0, "message": f"Error in query, please rectify (get_advisory()) - since_jun1"}
    except ConnectionError:
        return {"status": 0, "message": f"Couldn't connect to imd-druid database (get_advisory()) - since_jun1"}
    # except IndexError:
    #     return {"status": 0, "message": f"No results for selected block (get_advisory()) - since_jun1"}

    
    last_week = {}
    try:
        query2 = f"""
            SELECT ROUND(SUM("grid_rainfall"), 2), ROUND(AVG("grid_temp_max"), 2), ROUND(AVG("grid_temp_min"), 2)
            FROM "druid"."grid-rainfall-data" WHERE "block_id"={block_id}
            AND "__time">='{(date.today() - timedelta(days=6)).strftime("%Y-%m-%d")}T00:00:00.000Z'
            AND "__time"<='{(date.today() - timedelta(days=1)).strftime("%Y-%m-%d")}T00:00:00.000Z'
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query2_result = pd.DataFrame(connection.execute(query2), dtype=object).to_records()[0]
            last_week.update({"rainfall": query2_result[1], "max_temp": query2_result[2], "min_temp": query2_result[3]})
    except ProgrammingError:
        return {"status": 0, "message": f"Error in query, please rectify (get_advisory()) - last_week"}
    except ConnectionError:
        return {"status": 0, "message": f"Couldn't connect to imd-druid database (get_advisory()) - last_week"}
    except IndexError:
        return {"status": 0, "message": f"No results for selected block (get_advisory()) - last_week"}

    next_week = {}
    try:
        query3 = f"""
            SELECT ROUND(SUM("rainfall"), 2), ROUND(AVG("temp_max"), 2), ROUND(AVG("temp_min"), 2), ROUND(AVG(("humidity_I"+"humidity_II")/2), 2)
            FROM "druid"."medium-range-forecast" WHERE "block_id"={block_id}
            AND "__time">='{date.today().strftime("%Y-%m-%d")}T00:00:00.000Z'
            AND "__time"<='{(date.today() + timedelta(days=5)).strftime("%Y-%m-%d")}T00:00:00.000Z'
        """
        with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
            query3_result = pd.DataFrame(connection.execute(query3), dtype=object).to_records()[0]
            next_week.update({"rainfall": query3_result[1], "max_temp": query3_result[2], "min_temp": query3_result[3], "humidity": query3_result[4]})
    except ProgrammingError:
        return {"status": 0, "message": f"Error in query, please rectify (get_advisory()) - next_week"}
    except ConnectionError:
        return {"status": 0, "message": f"Couldn't connect to imd-druid database (get_advisory()) - next_week"}
    except IndexError:
        return {"status": 0, "message": f"No results for selected block (get_advisory()) - next_week"}
    

    today = date.today()
    end_day = today + timedelta(weeks=4)
    date_diff = (end_day - today).days
    date_list = [today]
    for i in range(1, date_diff):
        date_list.append(today + timedelta(days=i))
    wednesday_list = list(filter(lambda x: x.weekday() == 2, date_list))
    four_weeks = []
    wk = 0
    for wednesday in wednesday_list:
        start_day = wednesday
        end_day = start_day + timedelta(days=6)
        wk += 1
        four_weeks.append({"week": wk, "start": start_day, "end": end_day})
    
    cy_forecast = []
    for i in four_weeks:
        try:
            query4 = f"""
                SELECT ROUND(SUM("forecast_rainfall"), 1) FROM "druid"."extended-range-forecast"
                WHERE "__time">='{i["start"].strftime(("%Y-%m-%d"))}T00:00:00.000Z' 
                AND "__time"<='{i["end"].strftime("%Y-%m-%d")}T00:00:00.000Z' AND "block_id"={block_id} 
                AND "year"={current_year}
            """
            with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
                query4_result = list(pd.DataFrame(connection.execute(query4), dtype=object).to_records())
                if(len(query4_result)):
                    cy_forecast.append({"week": i["week"], "rf": query4_result[0][1]})
                else:
                    cy_forecast.append({"week": i["week"], "rf": None})
        except ProgrammingError:
            return {"status": 0, "message": "Error in query, please rectify (get_advisory()) - current year forecast"}
        except ConnectionError:
            return {"status": 0, "message": "Couldn't connect to imd-druid database (get_advisory()) - current year forecast"}
        except IndexError:
            return {"status": 0, "message": "No results for selected block (get_advisory()) - current year forecast"}
    
    py_observed = []
    for year in range(current_year-30, current_year):
        for i in four_weeks:
            try:
                query5 = f"""
                    SELECT ROUND(SUM("grid_rainfall"), 1) FROM "druid"."grid-rainfall-data"
                    WHERE "year"={year} AND "block_id"={block_id}
                    AND "__time">='{year}-{i["start"].strftime("%m-%d")}T00:00:00.000Z'
                    AND "__time"<='{year}-{i["end"].strftime("%m-%d")}T00:00:00.000Z'
                """
                with connect(host=druid["host"], port=druid["port"], path=druid["path"], scheme=druid["scheme"]) as connection:
                    query5_result = list(pd.DataFrame(connection.execute(query5), dtype=object).to_records())
                    if(len(query5_result)):
                        py_observed.append({"week": i["week"], "year": year, "rf": query5_result[0][1]})
                    else:
                        py_observed.append({"week": i["week"], "year": year, "rf": None})
            except ProgrammingError:
                return {"status": 0, "message": f"Error in query, please rectify (get_advisory()) - observed {year}"}
            except ConnectionError:
                return {"status": 0, "message": f"Couldn't connect to imd-druid database (get_advisory()) - observed {year}"}
            except IndexError:
                return {"status": 0, "message": f"No results for selected block (get_advisory()) - observed {year}"}

    py_observed_average = []
    for i in four_weeks:
        past_vals = list(filter(lambda x: x["week"] == i["week"], py_observed))
        past_vals_rf = list(map(lambda x: x["rf"] if isinstance(x["rf"], (int, float)) else 0, past_vals))
        py_observed_average.append({"week": i["week"], "rf": round((sum(past_vals_rf)/len(past_vals_rf)), 2)}) 

    for i in cy_forecast:
        obs = next(j for j in py_observed_average if j["week"] == i["week"])
        i["hist_avg_obs_rf"] = obs["rf"]
        i["outlook"] = ("AN" if i["rf"] >= obs["rf"] else "BN") if isinstance(i["rf"], (int, float)) else None

    # CALL ISAT FOR STATION DATA, IF NOT AVAILABLE LEAVE IT, CONSIDER GRIDDED DATA
    # SEND 2ND WEEK OUTLOOK AND BLOCK ID, IF BLOCK ID IS PRESENT THERE FETCH SINCE_JUN1 AND LAST WEEK GRIDDED DATA AND ADVISORY
    isat_message = ""
    station_rf_available = False
    try:
        req_headers = {"Content-Type": "application/json"}
        req_data = {"outlook": cy_forecast[1]['outlook'] or "", "blockId": block_id, "nextWeekRF": next_week["rainfall"]}
        isat_response = post("https://isat.icrisat.org/get_in_advisory_ngn/", headers=req_headers, json=req_data)
        if isat_response.status_code == 200:
            isat_response_json = isat_response.json()
            last_week["rainfall"] = isat_response_json["data"]["last_week"]
            since_jun1["rainfall"] = isat_response_json["data"]["since_jun1"]
            isat_message = isat_response_json["data"]["decision_message"]
            station_rf_available = True
        else:
            station_rf_available = False
    except (JSONDecodeError, ConnectionError):
        station_rf_available = False

    data = {
        "since_jun1": since_jun1,
        "last_week": last_week,
        "next_week": next_week,
        "current_year_forecast": cy_forecast
    }

    if isat_message and station_rf_available:
        data["station_rf_available"] = station_rf_available
        data["isat_message"] = isat_message

    return {"status": 1, "data": data}
