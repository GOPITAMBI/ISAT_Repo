from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from .fetch_druid import current_year, get_advisory
from django.utils.timezone import now
from datetime import datetime, timedelta


@csrf_exempt
@require_http_methods(['POST'])
def advisory(request):
    try:
        request_body = eval(request.body)
        block_id = int(request_body["blockId"]) if "blockId" in request_body else 0
        if block_id:
            result = get_advisory(block_id=block_id)
            return JsonResponse(result, status = 200 if result["status"] else 400)
        else:
            return JsonResponse({"status": 0, "message": "Block is required. Either its invalid or unavailable"}, status=400)
    except SyntaxError:
        return JsonResponse({"status": 0, "message": "Request body is missing / text cannot be evaluated into object. At least block is required"}, status=400)
    except (TypeError, ValueError):
        return JsonResponse({"status": 0, "message": "Cannot process due to invalid inputs, please check args"}, status=400)
